﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prackt13
{
    public partial class Form1 : Form
    {
        private DataGridViewColumn dataGridViewColumn1 = null;
        private DataGridViewColumn dataGridViewColumn2 = null;
        private DataGridViewColumn dataGridViewColumn3 = null;
        private DataGridViewColumn dataGridViewColumn4 = null;
        private SortedSet<Kostym> kostyms = new SortedSet<Kostym>();

        private void initDataGridView()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Columns.Add(getdataGridViewColumn1());
            dataGridView1.Columns.Add(getdataGridViewColumn2());
            dataGridView1.Columns.Add(getdataGridViewColumn3());
            dataGridView1.Columns.Add(getdataGridViewColumn4());
            dataGridView1.AutoResizeColumns();
        }
        private DataGridViewColumn getdataGridViewColumn1()
        {
            if (dataGridViewColumn1 == null)
            {
                dataGridViewColumn1 = new DataGridViewTextBoxColumn();
                dataGridViewColumn1.Name = "";
                dataGridViewColumn1.HeaderText = "Имя заказчика";
                dataGridViewColumn1.ValueType = typeof(string);
                dataGridViewColumn1.Width = dataGridView1.Width / 4;
            }
            return dataGridViewColumn1;
        }
        private DataGridViewColumn getdataGridViewColumn2()
        {
            if (dataGridViewColumn2 == null)
            {
                dataGridViewColumn2 = new DataGridViewTextBoxColumn();
                dataGridViewColumn2.Name = "";
                dataGridViewColumn2.HeaderText = "ткань костюма";
                dataGridViewColumn2.ValueType = typeof(string);
                dataGridViewColumn2.Width = dataGridView1.Width / 4;
            }
            return dataGridViewColumn2;
        }
        private DataGridViewColumn getdataGridViewColumn3()
        {
            if (dataGridViewColumn3 == null)
            {
                dataGridViewColumn3 = new DataGridViewTextBoxColumn();
                dataGridViewColumn3.Name = "";
                dataGridViewColumn3.HeaderText = "размер костюма";
                dataGridViewColumn3.ValueType = typeof(string);
                dataGridViewColumn3.Width = dataGridView1.Width / 4;
            }
            return dataGridViewColumn3;
        }
        private DataGridViewColumn getdataGridViewColumn4()
        {
            if (dataGridViewColumn4 == null)
            {
                dataGridViewColumn4 = new DataGridViewTextBoxColumn();
                dataGridViewColumn4.Name = "";
                dataGridViewColumn4.HeaderText = "страна производителя";
                dataGridViewColumn4.ValueType = typeof(string);
                dataGridViewColumn4.Width = dataGridView1.Width / 4;
            }
            return dataGridViewColumn4;
        }
        static SortedSet<string> nam = new SortedSet<string>();
        string[] arr = new string[nam.Count()];
        private void showListInGrid()
        {
            dataGridView1.Rows.Clear();
            foreach (Kostym s in kostyms)
            {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell cell1 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell2 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell3 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell4 = new DataGridViewTextBoxCell();
                cell1.ValueType = typeof(string);
                cell1.Value = s.getname();
                cell2.ValueType = typeof(string);
                cell2.Value = s.gettkan();
                cell3.ValueType = typeof(string);
                cell3.Value = s.getrazmer();
                cell4.ValueType = typeof(string);
                cell4.Value = s.getstrana();
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                row.Cells.Add(cell4);
                dataGridView1.Rows.Add(row);
            }
        }
        private void addTheApplication(string name, string tkan, string razmer, string strana)
        {
            int k = 0;
            foreach (Kostym prov in kostyms)
            {
                if (prov.getname() == name ) k++;
            }

            if (k == 0)
            {
                Kostym info = new Kostym(name, tkan, razmer, strana);
                kostyms.Add(info);           
                showListInGrid();
            }
            else MessageBox.Show("Такой заказчик уже существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void correctTheApplicant(string name, string tkan, string razmer, string strana)
        {
            int k = 0;
            foreach (Kostym prov in kostyms)
            {
                if (prov.getname() == name) k++;
            }

            if (k == 0)
            {
                Kostym info = new Kostym(name, tkan, razmer, strana);
                kostyms.Add(info);
                showListInGrid();
            }
            else MessageBox.Show("Такой заказчик уже существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
        }
        public Form1()
        {
            InitializeComponent();
            initDataGridView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Kostym student = new Kostym("", "","","");
            string name = textBox2.Text;
            if (name != "")
            {
                student.setname(name);
                string tkan = textBox1.Text;
                if (name != "")
                {
                    student.settkan(tkan);
                    string razmer = textBox3.Text;
                    if (razmer != "")
                    {
                        student.setrazmer(razmer);
                        string strana = textBox5.Text;
                        student.setstrana(strana);
                        addTheApplication(student.getname(), student.gettkan(), student.getrazmer(), student.getstrana());
                    }
                    else MessageBox.Show($"Поле 'Отчество' пустое", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else MessageBox.Show($"Поле 'Фамилия' пустое", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show($"Поле 'Имя' пустое", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int a = dataGridView1.SelectedCells[0].RowIndex;
            DialogResult b = MessageBox.Show("Вы действительно хотите редактировать данную строку?", "Информация", MessageBoxButtons.YesNo);
            if (b == DialogResult.Yes)
            {

                Kostym student = new Kostym("", "", "", "");
                string name = textBox2.Text;
                student.setname(name);
                string tkan = textBox1.Text;
                student.settkan(tkan);
                string razmer = textBox3.Text;
                student.setrazmer(razmer);
                string strana = textBox5.Text;
                student.setstrana(strana);
                correctTheApplicant(name, tkan, razmer, strana);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Ascending);
             button1.Enabled = false;
                groupBox1.Enabled = false;
                label5.Visible = true;
                textBox4.Visible = true;
                button3.Visible = true;
                dataGridView1.Sort(dataGridView1.Columns[1], ListSortDirection.Ascending);
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            arr = nam.ToArray();
            Array.Sort(arr);
            button2.Enabled = false;
            string name = textBox1.Text;
            if (nam.Contains($"{name}"))
            {
                MessageBox.Show($"Позиция, которую вы ищите {Array.IndexOf(arr,name) + 1}", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else MessageBox.Show($"Такого имени нет в списке!", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
    }
}

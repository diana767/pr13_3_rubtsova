﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prackt13
{
    class Kostym
    {
        private string name;
        private string tkan;
        private string razmer;
        private string strana;

        public Kostym(string name, string tkan, string razmer, string strana)
        {
            this.name = name;
            this.tkan = tkan;
            this.razmer = razmer;
            this.strana = strana;
        }
        public string getname()
        {
            return this.name;
        }
        public void setname(string name)
        {
            this.name = name;
        }
        public string gettkan()
        {
            return this.tkan;
        }
        public void settkan(string tkan)
        {
            this.tkan = tkan;
        }
        public string getrazmer()
        {
            return this.razmer;
        }
        public void setrazmer(string razmer)
        {
            this.razmer = razmer;
        }
        public string getstrana()
        {
            return this.strana;
        }
        public void setstrana(string strana)
        {
            this.strana = strana;
        }
    }
}
